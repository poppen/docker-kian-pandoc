# kianマクロ

## 概要

TeX（pLaTeX）で日本語の公用文書を書くためのスタイルファイルです。

## 著作権

Copyright © 2016-2019 Seiichiro HATA

## 連絡先

<infotech@hata-o.jp>

バグ情報には，サンプルコードと出力結果を添付していただけますと，
解析に助かります。

ご要望やバグ情報のご連絡には，速やかに対応するように努めておりますが，
多忙のため，全てのメールにお返事はいたしかねますので，ご了承ください。

## ウェブページ

<http://hata-o.jp/kian/>

## 動作環境

pLaTeX2e/upLaTeX2e

## インストール方法

ZIPファイルの中の「kian」を適切な場所に移動させ，
必要であれば，「mktexlsr」又は「texhash」を実行するだけです。

### Windowsの場合

解凍したフォルダ内の「kian」フォルダを，適切なフォルダ
（「C:\texlive\texmf-local\tex\platex」や
「C:\w32tex\share\texmf-dist\tex\platex」等）に移動させ，
必要であれば，コマンドプロンプトで
「mktexlsr」又は「texhash」を実行してください。

TeX Liveをお使いの場合は，
インストーラー「INSTALL-windows.dat」を用意しました。
ただし，TeX Live 2015（Windows 10）環境でしかテストしておりませんので，
ある程度の知識をお持ち方は，手動インストールを強くお勧めします。

### Macintosh，FreeBSD，Linuxの場合

解凍したディレクトリ内の「kian」ディレクトリを，適切なディレクトリ
（「/usr/share/texlive/texmf-dist/tex/platex/」や
「/usr/local/texlive/texmf-local/tex/latex/」等）に移動させ，
必要であれば，ターミナルで
「sudo mktexlsr」又は「sudo texhash」を実行してください。

手動インストールが困難な方のために，
インストーラー「INSTALL-unixlike.sh」を用意しました。
ただし，十分なテストができておりませんので，
ある程度の知識をお持ち方は，手動インストールを強くお勧めします。
また，TeXのディレクトリ構成がOSやディストリビューションによって，
様々であるため，うまく機能しない可能性があります。

## アンインストール方法

### Windowsの場合

インストールした「kian」フォルダを削除し，
必要であれば，コマンドプロンプトで「mktexlsr」又は「texhash」を実行する。

### Macintosh，FreeBSD，Linuxの場合

インストールした「kian」ディレクトリを削除し，
必要であれば，ターミナルで「sudo mktexlsr」又は「sudo texhash」を実行する。

## 使用方法

下記のマニュアルをご覧ください。

<http://hata-o.jp/kian/index?manual>

## ライセンス

GNU General Public Licenseバージョン3 (GPLv3)又はその後継バージョン

GPLv3のライセンス条項は，LICENSE-GPLv3.txtをご覧ください。

## 免責条項

ライセンスに定められているとおり，本プログラムにより損害が発生したとしても，
著作権者は何らの損害賠償責任も負いませんので，ご注意ください。

作成した文書は，必ず内容を確認し，
意図した内容になっていることを確認したうえで，使用してください。

## ヒストリー

### 2016-10-30 v01(Hiroshima Station)をリリースしました。

- kian-page.styがv01になりました。
- kian-sect.styがv01になりました。
- kian-titl.styがv01になりました。
- kian-opti.styがv01になりました。

### 2017-10-30 v02(Enkobashi-cho)をリリースしました。

- kian-page.styがv02になりました。
    + コードを適正化しました。
    + 強制改行に関するバグを修正しました。
- kian-sect.styがv02になりました。
    + 目次の深さ指定（tocdepth）が効かないバクを修正しました。
    + 目次の題目が長い場合に，点線（dotfill）が消えるバグを修正しました。
    + sectionにオプションを導入しました。
    + 箇条書きの字下げのバグを修正しました。
- kian-titl.styがv02になりました。
    + minutodashを微調整しました。
    + 強制改行に関するバグを修正しました。
    + addressに郵便番号の出力機能を追加しました。
- kian-opti.styがv02になりました。
    + sectionのオプションに対応しました。
    + sectionの表示を微調整しました。

### 2018-11-02 v03(Matoba-cho)をリリースしました。

- kian-page.styがv03になりました。
    + verb関数とverbatim環境での空白の間延びを修正しました。
- kian-sect.styがv03になりました。
    + sectionにlabelが付かないバグを修正しました。
- kian-titl.styがv03になりました。
    + receiverに名前を均等割付けしないオプションを追加しました。
    + sender及びpersonに死亡日の出力機能を追加しました。

### 2019-04-01 v04(Inari-machi)をリリースしました。

- kian-titl.styがv04になりました。
    + 元号「令和」に対応しました。

### 2019-04-26 v05(Kanayama-cho)をリリースしました。

- kian-titl.styがv05になりました。
    + 元号「令和」に追加対応しました。

### 2019-05-29 v06(Ebisu-cho)をリリースしました。

- kian-titl.styがv06になりました。
    + バグを修正しました。

