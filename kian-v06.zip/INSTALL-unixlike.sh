#!/bin/sh

if [ ! -d kian ]; then
    /bin/echo "error: Can't find kian directory \"kian\"." > /dev/stderr
fi

# 確認
/bin/echo    'Automatic installation is not recomended.' > /dev/stderr
/bin/echo -n 'Do you want to continue? (yes|no) ' > /dev/stderr
read answer; test "${answer}" = 'yes' || exit

# TeXのディレクトリを検索
if   [ -d /usr/local/texlive/texmf-local ]; then
    # mac os x
    texhome=/usr/local/texlive/texmf-local
elif [ -d /usr/share/texmf ]; then
    # ubuntu
    texhome=/usr/share/texmf
else
    /bin/echo "error: Can't find TeX directory \"texmf\" or \"texmf-local\"." > /dev/stderr
    exit 1
fi
if [ ! -d $texhome/tex ]; then
    /bin/echo "error: Can't find TeX directory \"tex\"." > /dev/stderr
    exit 1
fi

# pLaTeXのインストールディレクトリを作成
if [ ! -d $texhome/tex/platex ]; then
    if ( ! mkdir -p $texhome/tex/platex ); then
	/bin/echo "error: Can't find TeX directory \"texmf\"." > /dev/stderr
	exit 1
    fi
fi

# kianマクロをアンインストール
if [ -d $texhome/tex/platex/kian ]; then
    if ( ! rm -rf $texhome/tex/platex/kian ); then
	/bin/echo "error: Can't remove kian directory \"kian\"." > /dev/stderr
	exit 1
    fi
fi

# kianマクロをインストール
if ( cp -Rp kian $texhome/tex/platex ); then
    chown -R root:root $texhome/tex/platex/kian
    chmod 755 $texhome/tex/platex/kian
    chmod 644 $texhome/tex/platex/kian/kian*.sty
else
    /bin/echo "error: Can't copy kian directory \"kian\"." > /dev/stderr
    exit 1
fi

# ls-Rがあればmktexlsr又はtexhashを実行
if [ -e $texhome/ls-R ]; then
    if   [ -x /usr/bin/mktexlsr ]; then
	/usr/bin/mktexlsr
    elif [ -x /usr/bin/texhash ]; then
	/usr/bin/texhash
    elif [ -x /usr/local/bin/mktexlsr ]; then
	/usr/local/bin/mktexlsr
    elif [ -x /usr/local/bin/texhash ]; then
	/usr/local/bin/texhash
    else
	/bin/echo "error: Can't find \"mktexlsr\" or \"texhash\"." > /dev/stderr
    fi
fi
